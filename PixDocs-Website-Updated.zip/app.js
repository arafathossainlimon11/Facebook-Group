/* PixDocs Core Utilities - Instant Dark Mode, Search, Filter & File Helpers */

(function initTheme() {
  const savedTheme = localStorage.getItem('pixdocs_theme') || 'light';
  document.documentElement.setAttribute('data-theme', savedTheme);
})();

document.addEventListener('DOMContentLoaded', () => {
  const themeBtn = document.getElementById('themeToggle');
  const updateIcon = (theme) => {
    if (themeBtn) {
      themeBtn.textContent = theme === 'dark' ? '☀️' : '🌙';
      themeBtn.setAttribute('aria-label', theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode');
    }
  };

  updateIcon(document.documentElement.getAttribute('data-theme'));

  if (themeBtn) {
    themeBtn.addEventListener('click', () => {
      const current = document.documentElement.getAttribute('data-theme');
      const next = current === 'dark' ? 'light' : 'dark';
      document.documentElement.setAttribute('data-theme', next);
      localStorage.setItem('pixdocs_theme', next);
      updateIcon(next);
    });
  }

  // Homepage Live Tool Search & Category Filter
  const searchInput = document.getElementById('toolSearch');
  const filterBtns = document.querySelectorAll('.filter-btn');
  const toolCards = document.querySelectorAll('.tool-card');
  const catSections = document.querySelectorAll('.category-section');

  let activeCategory = 'all';

  function filterTools() {
    const query = searchInput ? searchInput.value.toLowerCase().trim() : '';

    toolCards.forEach((card) => {
      const title = card.querySelector('h3').textContent.toLowerCase();
      const desc = card.querySelector('p').textContent.toLowerCase();
      const tags = (card.getAttribute('data-tags') || '').toLowerCase();
      const cat = card.getAttribute('data-category');

      const matchesSearch = !query || title.includes(query) || desc.includes(query) || tags.includes(query);
      const matchesCat = activeCategory === 'all' || cat === activeCategory;

      card.style.display = matchesSearch && matchesCat ? 'flex' : 'none';
    });

    catSections.forEach((section) => {
      const visibleCards = section.querySelectorAll('.tool-card[style*="display: flex"]');
      section.style.display = visibleCards.length > 0 ? 'block' : 'none';
    });
  }

  if (searchInput) {
    searchInput.addEventListener('input', filterTools);
  }

  filterBtns.forEach((btn) => {
    btn.addEventListener('click', () => {
      filterBtns.forEach((b) => b.classList.remove('active'));
      btn.classList.add('active');
      activeCategory = btn.getAttribute('data-filter');
      filterTools();
    });
  });
});

// Global Helpers for All 15 Tools
window.PixDocs = {
  formatBytes(bytes) {
    if (!bytes || bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  },

  downloadBlob(blob, filename) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 4000);
  },

  showToast(message) {
    let toast = document.getElementById('pixToast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'pixToast';
      toast.className = 'toast';
      document.body.appendChild(toast);
    }
    toast.textContent = message;
    toast.classList.add('show');
    clearTimeout(window._toastTimer);
    window._toastTimer = setTimeout(() => toast.classList.remove('show'), 3200);
  }
};
