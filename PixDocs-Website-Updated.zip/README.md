# PixDocs website package

This ZIP contains the website files at the repository root.

## Publish with GitHub Pages
1. Create or open the GitHub repository that will host PixDocs.
2. Extract this ZIP on your phone or computer.
3. Upload the files and folders inside the ZIP to the repository root (do not upload the ZIP itself).
4. In GitHub, open **Settings → Pages** and select the `main` branch and `/ (root)` folder.
5. First test the free `github.io` address. Connect `pixdocs.xyz` only after the new site is working.

## Important
- Keep your existing domain DNS records unchanged until the replacement site is tested.
- The existing Google Search Console verification, canonical URLs, sitemap, robots file, and tool pages were retained from the supplied project.
- Root asset references were normalized and a shared SVG favicon was added.
- The existing Text to PDF page's two banner scripts were retained. The supplied native banner script was also added to that page.
- The ad scripts load from a third-party domain (`bauval.org`). Confirm that you trust this provider and test ad behavior before making the site public.
- This package is based on the supplied source ZIP. It has not been live-tested in a browser, and no claim is made that every tool has been functionally verified.
